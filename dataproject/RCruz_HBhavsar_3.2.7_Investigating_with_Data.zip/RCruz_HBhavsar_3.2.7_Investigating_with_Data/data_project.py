'''
RCruz, HBhavsar
3.2.7 Data Project
Period 2 
'''
import matplotlib.pyplot as plt
import os.path

directory = os.path.dirname(os.path.abspath(__file__))  
directory += "\\Data"

def graph():
    death_rate = []
    colors = ['green', 'red']
    filename = os.path.join(directory, 'Data.csv')
    datafile = open(filename,'r')
    data = datafile.readlines()
    not_obese = 0
    obese = 0
    for line in data:
        infant_list = line
        if infant_list[0:6] == "Infant":
            numbers = infant_list.split(',')
            infant_list_numbers = []
            for number in numbers[1:-2]:
                infant_list_numbers.append(float(number))
            not_obese = ((infant_list_numbers[1])/1000)*1000000
            obese = ((sum(infant_list_numbers[3:6]))/1000)*1000000
            not_obese = int(not_obese)
            obese = int(obese)
            death_rate.append(not_obese)
            death_rate.append(obese)
    categories = ["Infant deaths for normal weight women (4,200 out of 25,110)", "Infant deaths for obese women (20,910 out of 25,110 )"] 
    fig, ax = plt.subplots(1, 1)
    ax.pie(death_rate, labels=categories, colors=colors, autopct= '%.0f%%')
    ax.set_aspect(1)
    ax.set_title('Percentage of infant deaths for obese women and normal weight women for a total of 25,110 infant deaths.')
    fig.show()
    
graph()